Yuanchen Liu & Wesley Minner

CS 143 Database Systems
Professor Carlo Zaniolo
Spring 2016

Spec: http://yellowstone.cs.ucla.edu/cs143/project/project1A.html

================================================================================
Project 1
================================================================================

To test functionality, perform the following steps:
1. make sqlrefresh
2. make phptest
3. Use a browser to view "http://localhost:1438/~cs143/"

*If data has already been loaded into MySQL, only need to do 'make phptest',
 then browse to the url above.

If 'make sqlrefesh' is giving errors try:
1. make sqlclean
2. make create
3. make load


DONE:
* create.sql (still need constaints from last part of project)
* load.sql
* queries.sql
* query.php
* violate.sql